#include "a.h"
using namespace kea;
using namespace std;

int main(int argc, char const *argv[])
{
    Tetris();
    return 0;
}

